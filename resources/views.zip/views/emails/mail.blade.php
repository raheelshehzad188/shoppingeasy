<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Account Opening</title>
</head> 
<body>
    <h1>Account Opening</h1>
    
    
   <h1>{{ $name }}</h1>
    <p>{!! $body !!}</p>
</body>
</html>